Auto text effect

1. Functionalities

   Create simple typing effect.
   Change the typing speed based on given value
